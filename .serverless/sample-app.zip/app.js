
const serverless = require('serverless-http');
const express = require('express');
const app = express();
const colors = require('./colors.js');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/media', express.static('media'))

let bg = template`body {
  background: linear-gradient(${0}deg, ${1}, ${2}, ${3}, ${4});
  background-size: 800% 800%;

      -webkit-animation: AnimationName 14s ease infinite;
      -moz-animation: AnimationName 14s ease infinite;
      animation: AnimationName 14s ease infinite;
    }

    @-webkit-keyframes AnimationName {
      0%{background-position:0% 50%}
      50%{background-position:100% 50%}
      100%{background-position:0% 50%}
    }
    @-moz-keyframes AnimationName {
      0%{background-position:0% 50%}
      50%{background-position:100% 50%}
      100%{background-position:0% 50%}
    }
    @keyframes AnimationName {
      0%{background-position:0% 50%}
      50%{background-position:100% 50%}
      100%{background-position:0% 50%}
    }`;

app.get('/1',(req,res) => {
  let h = Math.floor(Math.random() * (1000 - 70) + 70);
  const createSoundFloat = function (total)  {

    const half = Math.ceil(total/2);
    let rot = Math.floor(Math.random() * (80 - 20) + 20);
    let audio = `<audio controls>
                <source src="media/109-113.mp3" type="audio/mpeg">
              Your browser does not support the audio element.
              </audio>`;
    
    let c1 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    let c2 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    let c3 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    let c4 = colors.colors[Math.floor(Math.random() * colors.colors.length)];

    res.set('Content-Type', 'text/html');
    res.write("<html><head><style>" + bg(rot,c1,c2,c3,c4) + "</style></head><body>");
    do {

      res.write("<br>")

      if (total == half)
      {
        res.write(audio);
      }

      total-=1;
    }while (total)
  }

  createSoundFloat(h);
  res.write("</body></html>");
  res.end();
}); 



app.get('/2',(req,res) => {
  let h = Math.floor(Math.random() * (1200 - 70) + 70);
  const createImageFloat = function (total)  {

    const half = Math.ceil(total/2);
    let rot = Math.floor(Math.random() * (80 - 20) + 20);
    let audio = `<img src="media/ozmo.jpg" alt=""></img>`;
    
    let c1 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    let c2 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    let c3 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    res.set('Content-Type', 'text/html');
    res.write("<html><body style=\"background: linear-gradient(" + rot + "deg, " + c2 + "  0%," + c1 + " 51% , " + c3 + " 85%);\">");
    do {

      res.write("<br>")

      if (total == half)
      {
        res.write(audio);
      }

      total-=1;
    }while (total)

  }

  createSoundFloat(100000);
  res.write("</body></html>");
  res.end();
});




app.get('/',(req,res) => {
  const countDown = function (total)  {
    const array = ['K','N','3','J','O','X'];
    let ret = "";
    let rot = Math.floor(Math.random() * (80 - 20) + 20);
    let c1 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    let c2 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    let c3 = colors.colors[Math.floor(Math.random() * colors.colors.length)];
    res.set('Content-Type', 'text/html');
    res.write("<html><body style=\"background: linear-gradient(" + rot + "deg, " + c2 + "  0%," + c1 + " 51% , " + c3 + " 85%);\">");
    do {

      res.write("<span style=\"color :" + colors.colors[Math.floor(Math.random() * colors.colors.length)] + " \">")
      res.write(array[Math.floor(Math.random() * array.length)]);
      res.write("</span>")
      if (Math.ceil(Math.random() * 10000)%12 ==0)
      {
        res.write("</br>");
      }

      total-=1;
    }while (total)

  }

  let output = countDown(100000);
  res.write("</body></html>");
  res.end();
});

app.get('/api/info', (req, res) => {
  res.send({ application: 'sample-app', version: '1' });
});
app.post('/api/v1/getback', (req, res) => {
  res.send({ ...req.body });
});

if(process.argv != null   && process.argv[2] == "-l" ){
app.listen(3000, () => console.log(`Listening on: 3000`));
}else {
module.exports.handler = serverless(app);
}

