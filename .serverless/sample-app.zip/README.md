# Serverless Express Experiment

Working from https://bitbucket.org/blog/deploy-an-express-js-app-to-aws-lambda-using-the-serverless-framework 


